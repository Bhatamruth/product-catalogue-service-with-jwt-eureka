package com.casestudy.amruthvbhat.eurekaserverproductcatalogservice1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaserverProductCatalogService1ApplicationTests {

	@Test
	void contextLoads() {
	}

}

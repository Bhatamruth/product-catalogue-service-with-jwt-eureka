package com.casestudy.amruthvbhat.productcatalogueservice1.Model;



import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Gets the value of myField.
 *
 * @return the current value of myField
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class JwtResponse {
  private String jwtToken;
  private String username;

}
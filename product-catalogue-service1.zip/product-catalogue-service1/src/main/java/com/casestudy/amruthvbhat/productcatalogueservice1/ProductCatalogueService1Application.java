package com.casestudy.amruthvbhat.productcatalogueservice1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
/**
 * Indicates that the Spring Boot application should enable service discovery features.
 * This annotation is used to register the application with a service registry, such as
 * Netflix Eureka or Consul, so that it can be discovered by other services.
 *
 * <p>When this annotation is used, the application will attempt to register itself with
 * the service registry and also discover other services registered in the same registry.
 *
 * @see org.springframework.cloud.client.discovery.EnableDiscoveryClient
 */

@EnableDiscoveryClient
@SpringBootApplication
public class ProductCatalogueService1Application {
  public static void main(String[] args) {
    SpringApplication.run(ProductCatalogueService1Application.class, args);
  }

}






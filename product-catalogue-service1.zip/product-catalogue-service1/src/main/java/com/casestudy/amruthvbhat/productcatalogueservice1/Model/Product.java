package com.casestudy.amruthvbhat.productcatalogueservice1.Model;





import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

/**
 * This class represents an entity that can be persisted to a database.
 * It is annotated with the {@code @Entity} annotation to indicate that
 * it is a JPA entity.
 *
 * <p>Entities are typically used in the context of a JPA (Java Persistence
 * API) implementation to map Java objects to database tables.
 * 
 * <p>Example usage:
 * <pre>
 * {@code
 *   @Entity
 *   public class MyEntity {
 *       // ...
 *   }
 * }
 * </pre>
 *
 * @since 1.0
 */
@Entity
public class Product {
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Integer id;
  
  public void setId(Integer id) {
    this.id = id;
  }

  private String name;
  private float price;
  //updated on 11-09-23
  private String category; // Added category field
  
  public Product() {
  }
 
  /**
   * Creates a new Product instance with the specified ID, name, and price.
   *
   * @param id    The unique identifier for the product.
   * @param name  The name of the product.
   * @param price The price of the product.
   */
  public Product(Integer id, String name, float price) {
    this.id = id;
    this.setName(name);
    this.setPrice(price);
  }
 
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  public Integer getId() {
    return id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public float getPrice() {
    return price;
  }

  public void setPrice(float price) {
    this.price = price;
  }
	
  //updated on 11-09-23
  public String getCategory() {
    return category;
  }

  public void setCategory(String category) {
    this.category = category;
  }
 
  // other getters and setters...
}
package com.casestudy.amruthvbhat.productcatalogueservice1.Service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.casestudy.amruthvbhat.productcatalogueservice1.Model.Product;
import com.casestudy.amruthvbhat.productcatalogueservice1.Repository.ProductRepository;

/**
 * This class represents a service component in the application.
 * 
 * <p>
 * A service component is responsible for providing specific functionality
 * or services within the application. It may be used to perform business
 * logic, handle data access, or perform other tasks.
 * </p>
 * 
 * <p>
 * Example usage:
 * <pre>
 * {@code
 *   @Service
 *   public class MyService {
 *       // ... class implementation ...
 *   }
 * }
 * </pre>
 * </p>
 */
@SuppressWarnings("unused")
@Service 
@Transactional
public class ProductService {
 
  @Autowired
  private ProductRepository repo;
  
  public List<Product> listAll() {
    return repo.findAll();
  }
     
  public Product save(Product product) {
      // Save the product and return the saved entity
      return repo.save(product);
  }
     
  public Product get(Integer id) {
    return repo.findById(id).get();
  }
     
  //updated on 11-09-23
  public Product delete(Integer id) {
      // Check if the product exists
      Product product = repo.findById(id).orElseThrow(() -> new NoSuchElementException("Product with ID " + id + " not found"));

      // If the product exists, delete it and return the deleted product
      repo.deleteById(id);
      return product;
  }
  
  //updated on 11-09-23
  public List<Product> getProductsByCategory(String category) {
    // TODO Auto-generated method stub
    return repo.findByCategory(category);
  }

public List<Product> getProductsByCategoryAndPriceRange(String category, Double minPrice, Double maxPrice) {
	// TODO Auto-generated method stub
	return repo.findByCategoryAndPriceBetween(category, minPrice, maxPrice);
}

}






